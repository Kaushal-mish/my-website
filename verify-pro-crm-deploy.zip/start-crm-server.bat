@echo off
cd /d "%~dp0"
if not exist logs mkdir logs
echo [%date% %time%] Starting Verify Pro CRM watchdog >> logs\watchdog.log
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0keep-crm-online.ps1"
