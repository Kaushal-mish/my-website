$ErrorActionPreference = "Continue"

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$logDir = Join-Path $projectRoot "logs"
$nodeExe = "C:\Program Files\nodejs\node.exe"
$healthUrl = "http://127.0.0.1:5000/api/health"
$startLog = Join-Path $logDir "watchdog.log"

if (-not (Test-Path -LiteralPath $logDir)) {
  New-Item -ItemType Directory -Path $logDir | Out-Null
}

function Write-WatchLog($message) {
  "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $message" | Add-Content -LiteralPath $startLog
}

function Test-CrmHealth {
  try {
    $response = Invoke-RestMethod -Uri $healthUrl -TimeoutSec 5
    return [bool]$response.success
  } catch {
    return $false
  }
}

function Start-CrmServer {
  Write-WatchLog "Starting Verify Pro CRM server"
  $info = New-Object System.Diagnostics.ProcessStartInfo
  $info.FileName = $nodeExe
  $info.Arguments = "server.js"
  $info.WorkingDirectory = $projectRoot
  $info.UseShellExecute = $false
  $info.CreateNoWindow = $true
  $info.RedirectStandardOutput = $true
  $info.RedirectStandardError = $true

  $process = New-Object System.Diagnostics.Process
  $process.StartInfo = $info
  [void]$process.Start()
  Write-WatchLog "Started node server.js with PID $($process.Id)"
}

Write-WatchLog "Verify Pro CRM watchdog started"

while ($true) {
  if (-not (Test-CrmHealth)) {
    Start-CrmServer
    Start-Sleep -Seconds 8
  }
  Start-Sleep -Seconds 20
}
