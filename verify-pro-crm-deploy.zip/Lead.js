const mongoose = require("mongoose");

const leadSchema = new mongoose.Schema(
  {
    leadId: {
      type: String,
      unique: true,
      trim: true
    },
    fullName: {
      type: String,
      required: [true, "Full name is required"],
      trim: true
    },
    leadType: {
      type: String,
      enum: ["Individual Patient", "Corporate Client"],
      default: "Individual Patient"
    },
    patientName: {
      type: String,
      trim: true
    },
    patientAge: {
      type: Number,
      min: 0,
      max: 120
    },
    patientGender: {
      type: String,
      enum: ["Male", "Female", "Other", ""],
      default: ""
    },
    email: {
      type: String,
      trim: true,
      lowercase: true
    },
    phone: {
      type: String,
      trim: true
    },
    companyName: {
      type: String,
      trim: true
    },
    city: {
      type: String,
      trim: true
    },
    state: {
      type: String,
      trim: true
    },
    leadSource: {
      type: String,
      trim: true,
      default: "Manual"
    },
    industry: {
      type: String,
      trim: true
    },
    leadScore: {
      type: Number,
      min: 0,
      max: 100,
      default: 0
    },
    budget: {
      type: Number,
      min: 0,
      default: 0
    },
    assignedExecutive: {
      type: String,
      trim: true
    },
    status: {
      type: String,
      enum: ["New", "Contacted", "In Progress", "Follow-up", "Qualified", "Proposal Sent", "Negotiation", "Converted", "Lost"],
      default: "New"
    },
    pipelineStage: {
      type: String,
      enum: ["New", "Attempted Contact", "Contacted", "Qualified", "Proposal Sent", "Negotiation", "Follow-Up", "Won", "Lost"],
      default: "New"
    },
    priority: {
      type: String,
      enum: ["Low", "Medium", "High", "Urgent"],
      default: "Medium"
    },
    testPackage: {
      type: String,
      trim: true
    },
    tests: {
      type: [String],
      default: []
    },
    doctorName: {
      type: String,
      trim: true
    },
    sampleType: {
      type: String,
      trim: true
    },
    sampleCollectionDate: Date,
    reportDeliveryDate: Date,
    reportStatus: {
      type: String,
      enum: ["Pending", "Sample Collected", "Processing", "Report Ready", "Delivered", ""],
      default: "Pending"
    },
    documents: {
      type: [String],
      default: []
    },
    paymentStatus: {
      type: String,
      enum: ["Pending", "Partial", "Paid", ""],
      default: "Pending"
    },
    followUpDate: Date,
    notes: {
      type: String,
      trim: true
    }
  },
  {
    timestamps: true
  }
);

leadSchema.index({ email: 1 }, { sparse: true });
leadSchema.index({ phone: 1 });
leadSchema.index({ status: 1, createdAt: -1 });
leadSchema.index({ fullName: "text", companyName: "text", email: "text", phone: "text" });

leadSchema.pre("validate", async function assignLeadId() {
  if (!this.leadId) {
    const count = await mongoose.models.Lead.countDocuments();
    this.leadId = `DYGO-${new Date().getFullYear()}-${String(count + 1).padStart(5, "0")}`;
  }
});

module.exports = mongoose.models.Lead || mongoose.model("Lead", leadSchema);
