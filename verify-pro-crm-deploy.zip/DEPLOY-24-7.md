# Verify Pro CRM 24/7 Deployment

Local URL `127.0.0.1` only works while this laptop is on. For always-on access when the laptop is off, run this project on a cloud server and use MongoDB Atlas.

## Required Environment Variables

```env
MONGO_URI=mongodb+srv://USER:PASSWORD@CLUSTER.mongodb.net/verifypro
PORT=5000
```

## Deploy With Render

1. Push this folder to GitHub.
2. Create a MongoDB Atlas database and copy the connection string.
3. In Render, create a new Web Service from the GitHub repo.
4. Use:
   - Build Command: `npm ci`
   - Start Command: `npm start`
   - Health Check Path: `/api/health`
5. Add environment variable `MONGO_URI` with the MongoDB Atlas connection string.
6. Deploy.

After deploy, open the Render service URL and login:

```text
admin@dygodiagnostics.com
admin123
```

## Deploy With Any VPS

```powershell
npm ci --omit=dev
$env:MONGO_URI="mongodb+srv://USER:PASSWORD@CLUSTER.mongodb.net/verifypro"
$env:PORT="5000"
npm start
```

For a permanent VPS process, run it under the server provider's process manager, system service, Docker, or PM2.

## Docker

```powershell
docker build -t verify-pro-crm .
docker run -p 5000:5000 -e MONGO_URI="mongodb+srv://USER:PASSWORD@CLUSTER.mongodb.net/verifypro" verify-pro-crm
```

Health check:

```text
http://SERVER-IP:5000/api/health
```
