const path = require("node:path");
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config({ path: path.join(__dirname, ".env") });

const leadRoutes = require("./leadRoutes");
const Lead = require("./Lead");
const { Activity, ActivityLog, FollowUp, Notification, Setting, Task, TeamMember, User } = require("./CrmModels");

const app = express();
const PORT = Number(process.env.PORT || 5000);
const MONGO_URI = process.env.MONGO_URI || "mongodb://127.0.0.1:27017/verifypro";
const sessions = new Map();

app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(__dirname));

app.get("/", (_req, res) => {
  res.sendFile(path.join(__dirname, "lead-managment.html"));
});

app.get("/api/health", (_req, res) => {
  res.json({
    success: true,
    service: "Dygo Diagnostics CRM API",
    timestamp: new Date().toISOString()
  });
});

function createToken() {
  return `vp_${Date.now()}_${Math.random().toString(36).slice(2)}`;
}

async function logActivity(action, entity, entityId, details = {}, actor = "System") {
  await ActivityLog.create({ action, entity, entityId: String(entityId || ""), details, actor });
}

async function pushNotification(title, message, channel = "In-App") {
  return Notification.create({ title, message, channel, status: "Unread" });
}

app.post("/api/auth/login", async (req, res, next) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    const user = await User.findOne({ email });

    if (!user || user.password !== password || user.status !== "Active") {
      return res.status(401).json({ success: false, message: "Invalid credentials or suspended account" });
    }

    const token = createToken();
    sessions.set(token, { userId: user._id.toString(), role: user.role, createdAt: new Date() });
    await logActivity("login", "User", user._id, { email }, user.name);
    res.json({ success: true, token, user: { id: user._id, name: user.name, email: user.email, mobile: user.mobile, role: user.role } });
  } catch (error) {
    next(error);
  }
});

app.post("/api/auth/logout", (req, res) => {
  const token = String(req.body.token || req.headers.authorization || "").replace("Bearer ", "");
  sessions.delete(token);
  res.json({ success: true, message: "Logged out" });
});

app.post("/api/auth/forgot-password", async (req, res, next) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const user = await User.findOne({ email });
    if (user) {
      await pushNotification("Password reset requested", `${user.name} requested password help`, "Email");
    }
    res.json({ success: true, message: "If the account exists, reset instructions were queued." });
  } catch (error) {
    next(error);
  }
});

app.get("/api/auth/session", async (req, res) => {
  const token = String(req.headers.authorization || "").replace("Bearer ", "");
  const session = sessions.get(token);
  res.json({ success: true, authenticated: Boolean(session), session: session || null });
});

app.use("/api/leads", leadRoutes);

app.get("/api/dashboard", async (_req, res, next) => {
  try {
    await FollowUp.updateMany({ dueAt: { $lt: new Date() }, status: "Upcoming" }, { $set: { status: "Missed" } });
    const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    const [totalLeads, newLeads, convertedLeads, qualifiedLeads, lostLeads, followUpsDue, openTasks, revenueResult, monthlyRevenueResult, sourceReport, funnel, growth, executivePerformance, recentActivities] =
      await Promise.all([
        Lead.countDocuments(),
        Lead.countDocuments({ status: "New" }),
        Lead.countDocuments({ status: "Converted" }),
        Lead.countDocuments({ status: "Qualified" }),
        Lead.countDocuments({ status: "Lost" }),
        FollowUp.countDocuments({ status: { $in: ["Upcoming", "Missed"] } }),
        Task.countDocuments({ status: { $nin: ["Completed", "Cancelled"] } }),
        Lead.aggregate([
          { $match: { status: "Converted" } },
          { $group: { _id: null, revenue: { $sum: "$budget" } } }
        ]),
        Lead.aggregate([
          { $match: { status: "Converted", updatedAt: { $gte: monthStart } } },
          { $group: { _id: null, revenue: { $sum: "$budget" } } }
        ]),
        Lead.aggregate([{ $group: { _id: "$leadSource", count: { $sum: 1 } } }, { $sort: { count: -1 } }]),
        Lead.aggregate([{ $group: { _id: "$pipelineStage", count: { $sum: 1 }, value: { $sum: "$budget" } } }]),
        Lead.aggregate([
          { $group: { _id: { $dateToString: { format: "%Y-%m", date: "$createdAt" } }, count: { $sum: 1 } } },
          { $sort: { _id: 1 } },
          { $limit: 12 }
        ]),
        Lead.aggregate([
          { $group: { _id: "$assignedExecutive", assigned: { $sum: 1 }, converted: { $sum: { $cond: [{ $eq: ["$status", "Converted"] }, 1, 0] } }, revenue: { $sum: { $cond: [{ $eq: ["$status", "Converted"] }, "$budget", 0] } } } },
          { $sort: { revenue: -1 } }
        ]),
        Activity.find().sort({ createdAt: -1 }).limit(8)
      ]);

    res.json({
      success: true,
      data: {
        totalLeads,
        newLeads,
        convertedLeads,
        qualifiedLeads,
        lostLeads,
        followUpsDue,
        openTasks,
        revenue: revenueResult[0]?.revenue || 0,
        monthlyRevenue: monthlyRevenueResult[0]?.revenue || 0,
        conversionRate: totalLeads ? Math.round((convertedLeads / totalLeads) * 1000) / 10 : 0,
        sourceReport: sourceReport.map((item) => ({ source: item._id || "Unknown", count: item.count })),
        funnel: funnel.map((item) => ({ stage: item._id || "New", count: item.count, value: item.value })),
        growth: growth.map((item) => ({ month: item._id, count: item.count })),
        executivePerformance: executivePerformance.map((item) => ({ executive: item._id || "Unassigned", assigned: item.assigned, converted: item.converted, revenue: item.revenue })),
        recentActivities
      }
    });
  } catch (error) {
    next(error);
  }
});

app.patch("/api/leads/:id/stage", async (req, res, next) => {
  try {
    const stage = String(req.body.stage || "").trim();
    const statusMap = {
      New: "New",
      Contacted: "Contacted",
      Qualified: "Qualified",
      "Proposal Sent": "Proposal Sent",
      Negotiation: "Negotiation",
      Won: "Converted",
      Lost: "Lost"
    };
    const lead = await Lead.findByIdAndUpdate(
      req.params.id,
      { pipelineStage: stage, status: statusMap[stage] || req.body.status || "In Progress" },
      { new: true, runValidators: true }
    );

    if (!lead) {
      return res.status(404).json({ success: false, message: "Lead not found" });
    }

    await Activity.create({
      type: "System",
      title: "Pipeline stage updated",
      message: `${lead.fullName} moved to ${stage}`,
      leadId: lead._id
    });
    if (stage === "Won") {
      await pushNotification("Lead converted", `${lead.fullName} converted. Revenue updated by ${lead.budget}.`);
    }
    await logActivity("stage.update", "Lead", lead._id, { stage });

    res.json({ success: true, data: lead });
  } catch (error) {
    next(error);
  }
});

app.get("/api/tasks", async (_req, res, next) => {
  try {
    const tasks = await Task.find().populate("leadId", "fullName companyName").sort({ dueDate: 1, createdAt: -1 });
    res.json({ success: true, count: tasks.length, data: tasks });
  } catch (error) {
    next(error);
  }
});

app.post("/api/tasks", async (req, res, next) => {
  try {
    const task = await Task.create(req.body);
    await Notification.create({ title: "Task created", message: task.title });
    await logActivity("task.create", "Task", task._id, { title: task.title });
    res.status(201).json({ success: true, data: task });
  } catch (error) {
    next(error);
  }
});

app.get("/api/followups", async (_req, res, next) => {
  try {
    await FollowUp.updateMany({ dueAt: { $lt: new Date() }, status: "Upcoming" }, { $set: { status: "Missed" } });
    const followUps = await FollowUp.find().populate("leadId", "fullName companyName").sort({ dueAt: 1 });
    res.json({ success: true, count: followUps.length, data: followUps });
  } catch (error) {
    next(error);
  }
});

app.post("/api/followups", async (req, res, next) => {
  try {
    const followUp = await FollowUp.create(req.body);
    await pushNotification("Follow Up Due", `${followUp.leadName} follow-up scheduled for ${followUp.assignedTo}`);
    await logActivity("followup.create", "FollowUp", followUp._id, { leadName: followUp.leadName });
    res.status(201).json({ success: true, data: followUp });
  } catch (error) {
    next(error);
  }
});

app.patch("/api/followups/:id", async (req, res, next) => {
  try {
    const followUp = await FollowUp.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!followUp) return res.status(404).json({ success: false, message: "Follow-up not found" });
    res.json({ success: true, data: followUp });
  } catch (error) {
    next(error);
  }
});

app.patch("/api/tasks/:id", async (req, res, next) => {
  try {
    const task = await Task.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!task) return res.status(404).json({ success: false, message: "Task not found" });
    res.json({ success: true, data: task });
  } catch (error) {
    next(error);
  }
});

app.get("/api/users", async (_req, res, next) => {
  try {
    const users = await User.find().sort({ role: 1, name: 1 });
    res.json({ success: true, count: users.length, data: users });
  } catch (error) {
    next(error);
  }
});

app.post("/api/users", async (req, res, next) => {
  try {
    const user = await User.create(req.body);
    res.status(201).json({ success: true, data: user });
  } catch (error) {
    next(error);
  }
});

app.get("/api/team", async (_req, res, next) => {
  try {
    const members = await TeamMember.find().sort({ name: 1 });
    res.json({ success: true, count: members.length, data: members });
  } catch (error) {
    next(error);
  }
});

app.post("/api/team", async (req, res, next) => {
  try {
    const member = await TeamMember.create(req.body);
    await logActivity("team.create", "TeamMember", member._id, { name: member.name });
    res.status(201).json({ success: true, data: member });
  } catch (error) {
    next(error);
  }
});

app.patch("/api/team/:id", async (req, res, next) => {
  try {
    const member = await TeamMember.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!member) return res.status(404).json({ success: false, message: "Team member not found" });
    res.json({ success: true, data: member });
  } catch (error) {
    next(error);
  }
});

app.delete("/api/team/:id", async (req, res, next) => {
  try {
    const member = await TeamMember.findByIdAndDelete(req.params.id);
    if (!member) return res.status(404).json({ success: false, message: "Team member not found" });
    res.json({ success: true, message: "Team member deleted" });
  } catch (error) {
    next(error);
  }
});

app.get("/api/notifications", async (_req, res, next) => {
  try {
    const notifications = await Notification.find().sort({ createdAt: -1 }).limit(50);
    res.json({ success: true, count: notifications.length, data: notifications });
  } catch (error) {
    next(error);
  }
});

app.patch("/api/notifications/read", async (_req, res, next) => {
  try {
    await Notification.updateMany({ status: "Unread" }, { $set: { status: "Read" } });
    res.json({ success: true, message: "Notifications marked read" });
  } catch (error) {
    next(error);
  }
});

app.delete("/api/notifications", async (_req, res, next) => {
  try {
    await Notification.deleteMany({});
    res.json({ success: true, message: "Notifications cleared" });
  } catch (error) {
    next(error);
  }
});

app.get("/api/settings", async (_req, res, next) => {
  try {
    const records = await Setting.find();
    const settings = records.reduce((acc, item) => ({ ...acc, [item.key]: item.value }), {});
    res.json({ success: true, data: settings });
  } catch (error) {
    next(error);
  }
});

app.put("/api/settings", async (req, res, next) => {
  try {
    for (const [key, value] of Object.entries(req.body || {})) {
      await Setting.updateOne({ key }, { $set: { value } }, { upsert: true });
    }
    res.json({ success: true, message: "Settings saved" });
  } catch (error) {
    next(error);
  }
});

app.get("/api/reports", async (_req, res, next) => {
  try {
    const [sources, executives, statuses, daily, weekly, monthly] = await Promise.all([
      Lead.aggregate([{ $group: { _id: "$leadSource", leads: { $sum: 1 }, revenue: { $sum: "$budget" } } }, { $sort: { leads: -1 } }]),
      Lead.aggregate([{ $group: { _id: "$assignedExecutive", leads: { $sum: 1 }, converted: { $sum: { $cond: [{ $eq: ["$status", "Converted"] }, 1, 0] } } } }]),
      Lead.aggregate([{ $group: { _id: "$status", count: { $sum: 1 } } }]),
      Lead.countDocuments({ createdAt: { $gte: new Date(Date.now() - 86400000) } }),
      Lead.countDocuments({ createdAt: { $gte: new Date(Date.now() - 7 * 86400000) } }),
      Lead.countDocuments({ createdAt: { $gte: new Date(new Date().getFullYear(), new Date().getMonth(), 1) } })
    ]);
    res.json({ success: true, data: { sources, executives, statuses, daily, weekly, monthly } });
  } catch (error) {
    next(error);
  }
});

app.get("/api/exports/leads.csv", async (_req, res, next) => {
  try {
    const leads = await Lead.find().sort({ createdAt: -1 }).lean();
    const headers = ["Lead ID", "Full Name", "Email", "Mobile", "Company", "City", "State", "Industry", "Source", "Budget", "Score", "Executive", "Status", "Follow Up"];
    const rows = leads.map((lead) => [
      lead.leadId,
      lead.fullName,
      lead.email,
      lead.phone,
      lead.companyName,
      lead.city,
      lead.state,
      lead.industry,
      lead.leadSource,
      lead.budget,
      lead.leadScore,
      lead.assignedExecutive,
      lead.status,
      lead.followUpDate ? lead.followUpDate.toISOString().slice(0, 10) : ""
    ]);
    const csv = [headers, ...rows].map((row) => row.map((value) => `"${String(value ?? "").replaceAll('"', '""')}"`).join(",")).join("\n");
    res.setHeader("Content-Type", "text/csv");
    res.setHeader("Content-Disposition", "attachment; filename=dygo-leads.csv");
    res.send(csv);
  } catch (error) {
    next(error);
  }
});

app.get("/api/exports/leads.xls", async (_req, res, next) => {
  try {
    const leads = await Lead.find().sort({ createdAt: -1 }).lean();
    const html = `<table><tr><th>Lead ID</th><th>Name</th><th>Email</th><th>Mobile</th><th>Company</th><th>Status</th><th>Budget</th></tr>${leads
      .map((lead) => `<tr><td>${lead.leadId || ""}</td><td>${lead.fullName || ""}</td><td>${lead.email || ""}</td><td>${lead.phone || ""}</td><td>${lead.companyName || ""}</td><td>${lead.status || ""}</td><td>${lead.budget || 0}</td></tr>`)
      .join("")}</table>`;
    res.setHeader("Content-Type", "application/vnd.ms-excel");
    res.setHeader("Content-Disposition", "attachment; filename=dygo-leads.xls");
    res.send(html);
  } catch (error) {
    next(error);
  }
});

async function seedDefaults() {
  await User.deleteOne({ email: "admin@dygodiagnostics.com" });

  const defaultUsers = [
    { name: "Kush Admin", email: "kushadmin@dydo.com", mobile: "+919876543210", password: "admin123", role: "Admin", status: "Active", target: 0 },
    { name: "Rahul Sharma", email: "rahul@dygodiagnostics.com", role: "Sales Manager", status: "Active", target: 2500000 },
    { name: "Priya Verma", email: "priya@dygodiagnostics.com", role: "Team Leader", status: "Active", target: 1800000 },
    { name: "Neha Singh", email: "neha@dygodiagnostics.com", role: "Sales Executive", status: "Active", target: 1200000 },
    { name: "Aman Gupta", email: "aman@dygodiagnostics.com", role: "Support Executive", status: "Active", target: 900000 }
  ];

  for (const user of defaultUsers) {
    const update = user.email === "kushadmin@dydo.com" ? { $set: user } : { $setOnInsert: user };
    await User.updateOne({ email: user.email }, update, { upsert: true });
  }

  const members = await TeamMember.countDocuments();
  if (!members) {
    await TeamMember.insertMany([
      { name: "Rahul Sharma", email: "rahul@dygodiagnostics.com", role: "Manager", mobile: "+91 98765 32100", leadsAssigned: 12, leadsConverted: 5, revenueGenerated: 1250000 },
      { name: "Priya Verma", email: "priya@dygodiagnostics.com", role: "Sales Executive", mobile: "+91 98765 32101", leadsAssigned: 18, leadsConverted: 8, revenueGenerated: 2100000 },
      { name: "Neha Singh", email: "neha@dygodiagnostics.com", role: "Sales Executive", mobile: "+91 98765 32102", leadsAssigned: 14, leadsConverted: 4, revenueGenerated: 850000 }
    ]);
  }

  const settings = await Setting.countDocuments();
  if (!settings) {
    await Setting.insertMany([
      { key: "company", value: { name: "Dygo Diagnostics", email: "support@dygodiagnostics.com", phone: "+91 98765 43210" } },
      { key: "security", value: { twoFactorRequired: false, lockAfterAttempts: 5 } },
      { key: "notifications", value: { email: true, sms: false, whatsapp: true, inApp: true } }
    ]);
  }
}

app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: `Route not found: ${req.method} ${req.originalUrl}`
  });
});

app.use((error, _req, res, _next) => {
  const statusCode = error.statusCode || 500;
  res.status(statusCode).json({
    success: false,
    message: error.message || "Unexpected server error"
  });
});

async function start() {
  await mongoose.connect(MONGO_URI);
  await seedDefaults();
  console.log(`MongoDB connected: ${mongoose.connection.name}`);

  app.listen(PORT, () => {
    console.log(`Dygo CRM running at http://127.0.0.1:${PORT}`);
  });
}

start().catch((error) => {
  console.error("Failed to start server:", error.message);
  process.exitCode = 1;
});
