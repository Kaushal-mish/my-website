const mongoose = require("mongoose");

const taskSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    leadId: { type: mongoose.Schema.Types.ObjectId, ref: "Lead" },
    assignedTo: { type: String, trim: true, default: "Unassigned" },
    priority: { type: String, enum: ["Low", "Medium", "High", "Urgent"], default: "Medium" },
    status: { type: String, enum: ["Open", "In Progress", "Completed", "Cancelled"], default: "Open" },
    dueDate: Date,
    notes: { type: String, trim: true }
  },
  { timestamps: true }
);

const activitySchema = new mongoose.Schema(
  {
    type: { type: String, enum: ["Call", "Meeting", "Email", "WhatsApp", "Note", "System"], default: "System" },
    title: { type: String, required: true, trim: true },
    message: { type: String, trim: true },
    leadId: { type: mongoose.Schema.Types.ObjectId, ref: "Lead" },
    actor: { type: String, trim: true, default: "System" }
  },
  { timestamps: true }
);

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, trim: true, lowercase: true },
    mobile: { type: String, trim: true },
    password: { type: String, default: "Dygo@CRM2026" },
    role: {
      type: String,
      enum: ["Super Admin", "Admin", "Manager", "Sales Manager", "Team Leader", "Sales Executive", "Support Executive"],
      default: "Sales Executive"
    },
    status: { type: String, enum: ["Active", "Suspended"], default: "Active" },
    target: { type: Number, default: 0 }
  },
  { timestamps: true }
);

const followUpSchema = new mongoose.Schema(
  {
    leadId: { type: mongoose.Schema.Types.ObjectId, ref: "Lead" },
    leadName: { type: String, required: true, trim: true },
    type: { type: String, enum: ["Call", "Meeting", "Email", "WhatsApp"], default: "Call" },
    assignedTo: { type: String, trim: true, default: "Unassigned" },
    dueAt: { type: Date, required: true },
    status: { type: String, enum: ["Upcoming", "Missed", "Completed"], default: "Upcoming" },
    notes: { type: String, trim: true }
  },
  { timestamps: true }
);

const teamMemberSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, trim: true, lowercase: true },
    role: { type: String, default: "Sales Executive" },
    mobile: { type: String, trim: true },
    leadsAssigned: { type: Number, default: 0 },
    leadsConverted: { type: Number, default: 0 },
    revenueGenerated: { type: Number, default: 0 },
    status: { type: String, enum: ["Active", "Suspended"], default: "Active" }
  },
  { timestamps: true }
);

const activityLogSchema = new mongoose.Schema(
  {
    action: { type: String, required: true },
    entity: { type: String, required: true },
    entityId: String,
    actor: { type: String, default: "System" },
    details: { type: mongoose.Schema.Types.Mixed, default: {} }
  },
  { timestamps: true }
);

const notificationSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    message: { type: String, trim: true },
    channel: { type: String, enum: ["In-App", "Email", "SMS", "WhatsApp"], default: "In-App" },
    status: { type: String, enum: ["Unread", "Read"], default: "Unread" }
  },
  { timestamps: true }
);

const settingSchema = new mongoose.Schema(
  {
    key: { type: String, required: true, unique: true },
    value: { type: mongoose.Schema.Types.Mixed, required: true }
  },
  { timestamps: true }
);

module.exports = {
  Task: mongoose.models.Task || mongoose.model("Task", taskSchema),
  Activity: mongoose.models.Activity || mongoose.model("Activity", activitySchema),
  ActivityLog: mongoose.models.ActivityLog || mongoose.model("ActivityLog", activityLogSchema),
  FollowUp: mongoose.models.FollowUp || mongoose.model("FollowUp", followUpSchema),
  User: mongoose.models.User || mongoose.model("User", userSchema),
  TeamMember: mongoose.models.TeamMember || mongoose.model("TeamMember", teamMemberSchema),
  Notification: mongoose.models.Notification || mongoose.model("Notification", notificationSchema),
  Setting: mongoose.models.Setting || mongoose.model("Setting", settingSchema)
};
