function readCache(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key) || "null") ?? fallback;
  } catch {
    return fallback;
  }
}

const state = {
  token: localStorage.getItem("verifyProToken") || "",
  user: JSON.parse(localStorage.getItem("verifyProUser") || "null"),
  leads: readCache("verifyProLeads", []),
  followUps: readCache("verifyProFollowUps", []),
  team: readCache("verifyProTeam", []),
  notifications: readCache("verifyProNotifications", []),
  dashboard: readCache("verifyProDashboard", null),
  detailView: localStorage.getItem("verifyProDetailView") || "",
  detailSource: localStorage.getItem("verifyProDetailSource") || "",
  autoTimer: null
};

const leadSources = ["Website", "Facebook", "Google Ads", "Instagram", "Referral", "Direct Calls", "LinkedIn", "WhatsApp Campaign"];
const statuses = ["New", "Contacted", "Qualified", "Proposal Sent", "Negotiation", "Converted", "Lost"];
const stages = ["New", "Contacted", "Qualified", "Proposal Sent", "Negotiation", "Won", "Lost"];
const executives = ["Rahul Sharma", "Priya Verma", "Aman Gupta", "Neha Singh", "Arjun Mehta"];
const names = ["Rahul Sharma", "Priya Verma", "Aman Gupta", "Neha Singh", "Arjun Mehta"];
const cities = ["Delhi", "Mumbai", "Noida", "Gurugram", "Pune", "Bengaluru"];
const companies = ["Dygo Diagnostics", "TCS", "Infosys", "Wipro", "Reliance", "Zomato"];
const diagnosticPackages = [
  { package: "Full Body Checkup", tests: ["CBC", "LFT", "KFT", "Lipid Profile", "Thyroid Profile"], sample: "Blood" },
  { package: "Diabetes Care", tests: ["HbA1c", "Fasting Glucose", "PP Glucose", "Urine Routine"], sample: "Blood/Urine" },
  { package: "Cardiac Risk Profile", tests: ["Lipid Profile", "hs-CRP", "ECG", "Troponin I"], sample: "Blood" },
  { package: "Fever Panel", tests: ["CBC", "CRP", "Malaria Antigen", "Dengue NS1", "Typhoid IgM"], sample: "Blood" },
  { package: "Executive Health Package", tests: ["CBC", "LFT", "KFT", "Vitamin D", "Vitamin B12", "Thyroid Profile"], sample: "Blood" }
];
const doctors = ["Dr. Meera Nair", "Dr. Rajiv Khanna", "Dr. Kavita Rao", "Dr. Sandeep Bansal", "Dr. Nisha Kapoor"];
const documentTypes = ["Aadhaar Card", "Prescription", "Insurance Card", "Previous Report", "Payment Receipt"];

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => Array.from(document.querySelectorAll(selector));

function money(value) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(Number(value || 0));
}

function fmtDate(value) {
  if (!value) return "-";
  return new Intl.DateTimeFormat("en-IN", { dateStyle: "medium", timeStyle: value.includes?.("T") ? "short" : undefined }).format(new Date(value));
}

function pick(list) {
  return list[Math.floor(Math.random() * list.length)];
}

function toast(message) {
  const node = $("#toast");
  node.textContent = message;
  node.classList.remove("hidden");
  setTimeout(() => node.classList.add("hidden"), 2400);
}

function pushNotif(message) {
  toast(message);
}

window.pushNotif = pushNotif;

async function api(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(state.token ? { Authorization: `Bearer ${state.token}` } : {}),
      ...(options.headers || {})
    }
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.message || "Request failed");
  return payload;
}

function formObject(form) {
  return Object.fromEntries(new FormData(form).entries());
}

function showPage(id) {
  $$(".page").forEach((page) => page.classList.toggle("active", page.id === id));
  $$("#nav button").forEach((button) => button.classList.toggle("active", button.dataset.page === id));
}

function showApp() {
  $("#login").classList.add("hidden");
  $("#app").classList.remove("hidden");
  if (state.detailView) $("#dashboardDetails")?.classList.remove("hidden");
}

function showLogin() {
  $("#app").classList.add("hidden");
  $("#login").classList.remove("hidden");
}

async function loadAll() {
  const query = new URLSearchParams({
    search: $("#globalSearch")?.value || "",
    status: $("#statusFilter")?.value || ""
  });
  const [leads, dashboard, followUps, team, notifications] = await Promise.all([
    api(`/api/leads?${query}`),
    api("/api/dashboard"),
    api("/api/followups"),
    api("/api/team"),
    api("/api/notifications")
  ]);
  state.leads = leads.data || [];
  state.dashboard = dashboard.data || {};
  state.followUps = followUps.data || [];
  state.team = team.data || [];
  state.notifications = notifications.data || [];
  saveCache();
  render();
}

function saveCache() {
  localStorage.setItem("verifyProLeads", JSON.stringify(state.leads));
  localStorage.setItem("verifyProDashboard", JSON.stringify(state.dashboard || {}));
  localStorage.setItem("verifyProFollowUps", JSON.stringify(state.followUps));
  localStorage.setItem("verifyProTeam", JSON.stringify(state.team));
  localStorage.setItem("verifyProNotifications", JSON.stringify(state.notifications));
}

function render() {
  renderMetrics();
  renderLeadTable();
  renderPipeline();
  renderFollowUps();
  renderTeam();
  renderNotifications();
  renderLeadOptions();
  renderDashboardDetail();
}

function renderMetrics() {
  const d = state.dashboard || {};
  const metrics = [
    ["total", "Total Leads", d.totalLeads || state.leads.length],
    ["new", "New Leads", d.newLeads || state.leads.filter((lead) => lead.status === "New").length],
    ["qualified", "Qualified Leads", d.qualifiedLeads || state.leads.filter((lead) => lead.status === "Qualified").length],
    ["converted", "Converted Leads", d.convertedLeads || state.leads.filter((lead) => lead.status === "Converted").length],
    ["lost", "Lost Leads", d.lostLeads || state.leads.filter((lead) => lead.status === "Lost").length],
    ["followups", "Follow Ups Due", d.followUpsDue || state.followUps.filter((item) => item.status !== "Completed").length],
    ["revenue", "Monthly Revenue", money(d.monthlyRevenue || monthlyRevenue())],
    ["conversion", "Conversion Rate", `${d.conversionRate || conversionRate()}%`]
  ];
  $("#metricGrid").innerHTML = metrics.map(([view, label, value]) => `<button class="metric" type="button" data-dashboard-view="${view}"><span>${label}</span><strong>${value}</strong><small>Open details</small></button>`).join("");

  const sources = sourceGroups();
  const max = Math.max(1, ...sources.map((item) => item.count));
  $("#sourceBars").innerHTML = sources.length
    ? sources.map((item) => `<button class="bar source-button" type="button" data-dashboard-source="${item.source}"><div><strong>${item.source}</strong> <span>${item.count}</span></div><div class="bar-track"><div class="bar-fill" style="width:${(item.count / max) * 100}%"></div></div></button>`).join("")
    : `<p class="muted">No lead source data yet.</p>`;

  $("#activities").innerHTML = (d.recentActivities || []).length
    ? d.recentActivities.map((item) => `<article class="activity"><strong>${item.title}</strong><p>${item.message || ""}</p><small>${fmtDate(item.createdAt)}</small></article>`).join("")
    : `<p class="muted">Activity logs appear when leads are generated or changed.</p>`;
}

function monthlyRevenue() {
  const now = new Date();
  return state.leads
    .filter((lead) => lead.status === "Converted" && new Date(lead.updatedAt || lead.createdAt || Date.now()).getMonth() === now.getMonth())
    .reduce((sum, lead) => sum + Number(lead.budget || 0), 0);
}

function conversionRate() {
  if (!state.leads.length) return 0;
  return Math.round((state.leads.filter((lead) => lead.status === "Converted").length / state.leads.length) * 1000) / 10;
}

function normalizeSource(source) {
  const value = String(source || "Unknown").toLowerCase();
  if (value.includes("website")) return "Website";
  if (value.includes("facebook")) return "Facebook";
  if (value.includes("google")) return "Google Ads";
  if (value.includes("instagram")) return "Instagram";
  if (value.includes("referral")) return "Referral";
  if (value.includes("direct") || value.includes("call")) return "Direct Calls";
  return source || "Unknown";
}

function sourceGroups() {
  const groups = new Map();
  state.leads.forEach((lead) => {
    const source = normalizeSource(lead.leadSource);
    groups.set(source, { source, count: (groups.get(source)?.count || 0) + 1 });
  });
  return Array.from(groups.values()).sort((a, b) => b.count - a.count);
}

function packageForLead(lead) {
  const seed = String(lead.leadId || lead._id || lead.fullName || "").split("").reduce((sum, char) => sum + char.charCodeAt(0), 0);
  return diagnosticPackages[seed % diagnosticPackages.length];
}

function leadPatientName(lead) {
  return lead.patientName || lead.fullName || "-";
}

function leadTests(lead) {
  return Array.isArray(lead.tests) && lead.tests.length ? lead.tests : packageForLead(lead).tests;
}

function leadDocuments(lead) {
  return Array.isArray(lead.documents) && lead.documents.length ? lead.documents : documentTypes.slice(0, 3);
}

function leadPackageName(lead) {
  return lead.testPackage || packageForLead(lead).package;
}

function leadAccountName(lead) {
  return lead.companyName || "Individual Patient";
}

function leadType(lead) {
  return lead.leadType || (lead.companyName ? "Corporate Client" : "Individual Patient");
}

function badge(value) {
  const tone = ["Converted", "Won", "Completed"].includes(value) ? "success" : ["Lost", "Missed"].includes(value) ? "danger" : ["Qualified", "Proposal Sent", "Negotiation", "High", "Urgent"].includes(value) ? "warning" : "";
  return `<span class="badge ${tone}">${value || "-"}</span>`;
}

function openDashboardDetail(view, source = "") {
  const changed = state.detailView !== view || state.detailSource !== source;
  state.detailView = view;
  state.detailSource = source;
  localStorage.setItem("verifyProDetailView", view);
  localStorage.setItem("verifyProDetailSource", source);
  $("#dashboardDetails").classList.remove("hidden");
  if (changed) {
    $("#detailSearch").value = "";
    $("#detailFilter").dataset.view = "";
    $("#detailFilter").value = "";
  }
  renderDashboardDetail();
  $("#dashboardDetails").scrollIntoView({ behavior: "smooth", block: "start" });
}

function detailRowsFor(view, source) {
  const leads = state.leads.slice();
  if (view === "total") return leads;
  if (view === "new") return leads.filter((lead) => lead.status === "New");
  if (view === "qualified") return leads.filter((lead) => lead.status === "Qualified");
  if (view === "converted") return leads.filter((lead) => lead.status === "Converted");
  if (view === "lost") return leads.filter((lead) => lead.status === "Lost");
  if (view === "source") return leads.filter((lead) => normalizeSource(lead.leadSource) === source);
  if (view === "followups") return state.followUps.filter((item) => item.status !== "Completed");
  if (view === "revenue") return leads.filter((lead) => lead.status === "Converted");
  if (view === "conversion") return leads;
  return leads;
}

function detailTitle(view, source) {
  const titles = {
    total: "Total Leads",
    new: "Newly Generated Leads",
    qualified: "Qualified Prospects",
    converted: "Converted Customers",
    lost: "Lost Leads",
    followups: "Follow-ups Due",
    revenue: "Monthly Revenue",
    conversion: "Conversion Analytics",
    source: `${source || "Lead Source"} Leads`
  };
  return titles[view] || "Dashboard Details";
}

function renderDashboardDetail() {
  const section = $("#dashboardDetails");
  if (!state.detailView || !section || section.classList.contains("hidden")) return;

  const view = state.detailView;
  const source = state.detailSource;
  const rows = detailRowsFor(view, source);
  const query = ($("#detailSearch")?.value || "").toLowerCase();
  const filter = $("#detailFilter")?.value || "";
  const filtered = rows.filter((item) => detailMatches(item, view, query, filter));

  $("#detailTitle").textContent = detailTitle(view, source);
  $("#detailSummary").textContent = `${filtered.length} records shown from ${rows.length} matching live CRM records.`;
  renderDetailFilters(view);
  renderDetailStats(view, rows);
  renderDetailCharts(view, rows);
  renderDetailTable(view, filtered);
}

function detailMatches(item, view, query, filter) {
  const haystack = JSON.stringify(item).toLowerCase();
  const queryOk = !query || haystack.includes(query);
  if (!queryOk) return false;
  if (!filter) return true;
  if (view === "followups") return item.status === filter || item.assignedTo === filter;
  return item.status === filter || normalizeSource(item.leadSource) === filter || item.assignedExecutive === filter;
}

function renderDetailFilters(view) {
  const select = $("#detailFilter");
  if (!select || select.dataset.view === view) return;
  select.dataset.view = view;
  const values = view === "followups"
    ? [...new Set(state.followUps.flatMap((item) => [item.status, item.assignedTo]).filter(Boolean))]
    : [...new Set(state.leads.flatMap((lead) => [lead.status, normalizeSource(lead.leadSource), lead.assignedExecutive]).filter(Boolean))];
  select.innerHTML = `<option value="">All</option>` + values.sort().map((value) => `<option>${value}</option>`).join("");
}

function renderDetailStats(view, rows) {
  const totalBudget = rows.reduce((sum, item) => sum + Number(item.budget || 0), 0);
  const converted = rows.filter((lead) => lead.status === "Converted").length;
  const stats = view === "followups"
    ? [
        ["Pending", rows.filter((item) => item.status === "Upcoming").length],
        ["Missed", rows.filter((item) => item.status === "Missed").length],
        ["Executives", new Set(rows.map((item) => item.assignedTo).filter(Boolean)).size]
      ]
    : [
        ["Records", rows.length],
        ["Pipeline Value", money(totalBudget)],
        ["Conversion", rows.length ? `${Math.round((converted / rows.length) * 1000) / 10}%` : "0%"]
      ];
  $("#detailStats").innerHTML = stats.map(([label, value]) => `<article class="mini-stat"><span>${label}</span><strong>${value}</strong></article>`).join("");
}

function renderDetailCharts(view, rows) {
  const groups = view === "followups"
    ? groupCounts(rows, (item) => item.status || "Upcoming")
    : view === "revenue"
      ? groupSums(rows, (lead) => new Date(lead.updatedAt || lead.createdAt || Date.now()).toLocaleString("en-IN", { month: "short", year: "numeric" }), (lead) => Number(lead.budget || 0))
      : view === "conversion"
        ? groupCounts(rows, (lead) => lead.status || "New")
        : groupCounts(rows, (lead) => normalizeSource(lead.leadSource));
  const max = Math.max(1, ...groups.map((item) => item.value));
  $("#detailCharts").innerHTML = groups.length
    ? groups.map((item) => `<div class="bar"><div><strong>${item.label}</strong><span>${view === "revenue" ? money(item.value) : item.value}</span></div><div class="bar-track"><div class="bar-fill" style="width:${(item.value / max) * 100}%"></div></div></div>`).join("")
    : `<p class="muted">No chart data available for this view.</p>`;
}

function groupCounts(rows, labeler) {
  const groups = new Map();
  rows.forEach((row) => {
    const label = labeler(row);
    groups.set(label, { label, value: (groups.get(label)?.value || 0) + 1 });
  });
  return Array.from(groups.values()).sort((a, b) => b.value - a.value);
}

function groupSums(rows, labeler, valueReader) {
  const groups = new Map();
  rows.forEach((row) => {
    const label = labeler(row);
    groups.set(label, { label, value: (groups.get(label)?.value || 0) + valueReader(row) });
  });
  return Array.from(groups.values()).sort((a, b) => b.value - a.value);
}

function renderDetailTable(view, rows) {
  if (view === "followups") {
    $("#detailHead").innerHTML = `<tr><th>Lead</th><th>Type</th><th>Executive</th><th>Due Date</th><th>Status</th><th>Notes</th></tr>`;
    $("#detailRows").innerHTML = rows.map((item) => `<tr><td>${item.leadName || "-"}</td><td>${item.type || "-"}</td><td>${item.assignedTo || "-"}</td><td>${fmtDate(item.dueAt)}</td><td>${badge(item.status)}</td><td>${item.notes || "-"}</td></tr>`).join("");
    return;
  }
  $("#detailHead").innerHTML = `<tr><th>Lead ID</th><th>Patient</th><th>Contact</th><th>Company</th><th>Tests</th><th>Documents</th><th>Report</th><th>Payment</th><th>Executive</th><th>Action</th></tr>`;
  $("#detailRows").innerHTML = rows.map((lead) => `<tr>
    <td>${lead.leadId || "-"}</td>
    <td><strong>${leadPatientName(lead)}</strong><div class="muted">${lead.patientAge || "-"} yrs · ${lead.patientGender || "-"}</div></td>
    <td>${lead.phone || "-"}<div class="muted">${lead.email || ""}</div></td>
    <td>${leadAccountName(lead)}<div class="muted">${leadType(lead)} · ${lead.city || "-"}</div></td>
    <td><strong>${leadPackageName(lead)}</strong><div class="muted">${leadTests(lead).join(", ")}</div></td>
    <td>${leadDocuments(lead).map((item) => badge(item)).join(" ")}</td>
    <td>${badge(lead.reportStatus || "Pending")}<div class="muted">${fmtDate(lead.reportDeliveryDate)}</div></td>
    <td>${badge(lead.paymentStatus || "Pending")}<div class="muted">${money(lead.budget)}</div></td>
    <td>${lead.assignedExecutive || "-"}<div class="muted">${normalizeSource(lead.leadSource)}</div></td>
    <td><button class="secondary" data-detail-view-lead="${lead._id}">View All</button></td>
  </tr>`).join("");
}

function exportDetailReport() {
  const view = state.detailView;
  const rows = detailRowsFor(view, state.detailSource).filter((item) => detailMatches(item, view, ($("#detailSearch")?.value || "").toLowerCase(), $("#detailFilter")?.value || ""));
  const isFollowUp = view === "followups";
  const headers = isFollowUp ? ["Lead", "Type", "Executive", "Due Date", "Status", "Notes"] : ["Lead ID", "Lead Type", "Patient", "Email", "Mobile", "Account", "Package", "Tests", "Documents", "Source", "Status", "Executive", "Budget", "Created"];
  const body = rows.map((item) => isFollowUp
    ? [item.leadName, item.type, item.assignedTo, item.dueAt, item.status, item.notes]
    : [item.leadId, leadType(item), leadPatientName(item), item.email, item.phone, leadAccountName(item), leadPackageName(item), leadTests(item).join("; "), leadDocuments(item).join("; "), normalizeSource(item.leadSource), item.status, item.assignedExecutive, item.budget, item.createdAt]);
  const csv = [headers, ...body].map((row) => row.map((value) => `"${String(value ?? "").replaceAll('"', '""')}"`).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `verify-pro-${view || "dashboard"}-report.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
}

function renderLeadTable() {
  $("#leadRows").innerHTML = state.leads.map((lead) => `
    <tr>
      <td>${lead.leadId || "-"}</td>
      <td><strong>${lead.fullName}</strong><div class="muted">${lead.email || ""}</div></td>
      <td>${lead.phone || "-"}</td>
      <td>${leadAccountName(lead)}</td>
      <td>${lead.leadSource || "-"}</td>
      <td>${badge(lead.status)}</td>
      <td>${lead.assignedExecutive || "-"}</td>
      <td class="row-actions">
        <button class="secondary" data-view="${lead._id}">View</button>
        <button class="secondary" data-edit="${lead._id}">Edit</button>
        <button class="ghost danger-text" data-delete="${lead._id}">Delete</button>
      </td>
    </tr>
  `).join("");
}

function renderPipeline() {
  $("#pipelineBoard").innerHTML = stages.map((stage) => {
    const leads = state.leads.filter((lead) => (lead.pipelineStage || "New") === stage || (stage === "Won" && lead.status === "Converted"));
    return `
      <section class="column" data-drop-stage="${stage}">
        <h3>${stage} ${badge(leads.length)}</h3>
        ${leads.map((lead) => `
          <article class="lead-card" draggable="true" data-drag-lead="${lead._id}">
            <strong>${lead.fullName}</strong>
            <p>${leadAccountName(lead)} · ${money(lead.budget)}</p>
            <p>${lead.assignedExecutive || "-"} · ${badge(lead.priority || "Medium")}</p>
          </article>
        `).join("")}
      </section>
    `;
  }).join("");
}

function renderLeadOptions() {
  const select = $("#followUpForm select[name='leadId']");
  select.innerHTML = `<option value="">Select Lead</option>` + state.leads.map((lead) => `<option value="${lead._id}">${lead.fullName} - ${leadAccountName(lead) || lead.phone || ""}</option>`).join("");
}

function renderFollowUps() {
  $("#followUpList").innerHTML = state.followUps.length
    ? state.followUps.map((item) => `<article class="task-card"><strong>${item.leadName}</strong><p>${item.type} with ${item.assignedTo} · ${fmtDate(item.dueAt)}</p>${badge(item.status)} <button class="secondary" data-follow-complete="${item._id}">Complete</button></article>`).join("")
    : `<p class="muted">No follow-ups scheduled.</p>`;
}

function renderTeam() {
  $("#teamList").innerHTML = state.team.map((member) => `
    <article class="user-card">
      <strong>${member.name}</strong>
      <p>${member.email} · ${member.mobile || ""}</p>
      <p>${member.role} · Assigned ${member.leadsAssigned || 0} · Converted ${member.leadsConverted || 0} · ${money(member.revenueGenerated || 0)}</p>
      <button class="secondary" data-team-edit="${member._id}">Edit</button>
      <button class="ghost danger-text" data-team-delete="${member._id}">Delete</button>
    </article>
  `).join("");
}

function renderNotifications() {
  const unread = state.notifications.filter((item) => item.status === "Unread").length;
  $("#unreadCount").textContent = unread;
  const markup = state.notifications.length
    ? state.notifications.map((item) => `<article class="notification"><strong>${item.title}</strong><p>${item.message || ""}</p>${badge(item.status)}</article>`).join("")
    : `<p class="muted">No notifications.</p>`;
  $("#notifications").innerHTML = markup;
  $("#notificationList").innerHTML = markup;
}

function clearLeadForm() {
  $("#leadForm").reset();
  $("#leadForm input[name='id']").value = "";
  $("#leadFormTitle").textContent = "Add Lead";
}

function clearTeamForm() {
  $("#teamForm").reset();
  $("#teamForm input[name='id']").value = "";
  $("#teamFormTitle").textContent = "Add Team Member";
}

function fillLeadForm(lead) {
  const form = $("#leadForm");
  form.id.value = lead._id;
  form.fullName.value = lead.fullName || "";
  form.email.value = lead.email || "";
  form.phone.value = lead.phone || "";
  form.companyName.value = lead.companyName || "";
  form.city.value = lead.city || "";
  form.state.value = lead.state || "";
  form.industry.value = lead.industry || "";
  form.leadSource.value = lead.leadSource || "Google Ads";
  form.budget.value = lead.budget || 0;
  form.leadScore.value = lead.leadScore || 50;
  form.assignedExecutive.value = lead.assignedExecutive || "";
  form.status.value = lead.status || "New";
  form.priority.value = lead.priority || "Medium";
  form.followUpDate.value = lead.followUpDate ? lead.followUpDate.slice(0, 10) : "";
  form.notes.value = lead.notes || "";
  $("#leadFormTitle").textContent = "Edit Lead";
  showPage("leads");
}

function showLeadDetails(lead) {
  $("#leadDetailsBody").innerHTML = `
    <h2>${leadPatientName(lead)}</h2>
    <p>${leadAccountName(lead)} · ${lead.phone || "-"}</p>
    <div class="detail-grid">
      <section>
        <h3>Patient Details</h3>
        <p><strong>Patient Name:</strong> ${leadPatientName(lead)}</p>
        <p><strong>Age / Gender:</strong> ${lead.patientAge || "-"} / ${lead.patientGender || "-"}</p>
        <p><strong>Email:</strong> ${lead.email || "-"}</p>
        <p><strong>Mobile:</strong> ${lead.phone || "-"}</p>
        <p><strong>City:</strong> ${lead.city || "-"} ${lead.state || ""}</p>
        <p><strong>Lead Type:</strong> ${leadType(lead)}</p>
      </section>
      <section>
        <h3>Test Details</h3>
        <p><strong>Package:</strong> ${leadPackageName(lead)}</p>
        <p><strong>Tests:</strong> ${leadTests(lead).join(", ")}</p>
        <p><strong>Doctor:</strong> ${lead.doctorName || pick(doctors)}</p>
        <p><strong>Sample:</strong> ${lead.sampleType || packageForLead(lead).sample}</p>
        <p><strong>Sample Date:</strong> ${fmtDate(lead.sampleCollectionDate)}</p>
      </section>
      <section>
        <h3>Documents</h3>
        <p>${leadDocuments(lead).map((item) => badge(item)).join(" ")}</p>
        <p><strong>Report Status:</strong> ${lead.reportStatus || "Pending"}</p>
        <p><strong>Report Delivery:</strong> ${fmtDate(lead.reportDeliveryDate)}</p>
        <p><strong>Payment:</strong> ${lead.paymentStatus || "Pending"} · ${money(lead.budget)}</p>
      </section>
      <section>
        <h3>Lead Details</h3>
        <p><strong>Lead ID:</strong> ${lead.leadId || "-"}</p>
        <p><strong>Source:</strong> ${lead.leadSource || "-"}</p>
        <p><strong>Status:</strong> ${lead.status || "-"}</p>
        <p><strong>Executive:</strong> ${lead.assignedExecutive || "-"}</p>
        <p><strong>Follow Up:</strong> ${fmtDate(lead.followUpDate)}</p>
        <p><strong>Notes:</strong> ${lead.notes || "-"}</p>
      </section>
    </div>
  `;
  $("#leadDetails").showModal();
}

function fillTeamForm(member) {
  const form = $("#teamForm");
  form.id.value = member._id;
  form.name.value = member.name || "";
  form.email.value = member.email || "";
  form.mobile.value = member.mobile || "";
  form.role.value = member.role || "Sales Executive";
  $("#teamFormTitle").textContent = "Edit Team Member";
}

function createAutoLead() {
  const fullName = pick(names);
  const isIndividual = Math.random() > 0.45;
  const companyName = isIndividual ? "" : pick(companies);
  const city = pick(cities);
  const leadSource = pick(leadSources);
  const assignedExecutive = pick(executives);
  const diagnostic = pick(diagnosticPackages);
  const phone = `9${Math.floor(100000000 + Math.random() * 899999999)}`;
  const budgetValues = [50000, 250000, 1000000, 12500000];
  const sampleDate = new Date(Date.now() + Math.floor(1 + Math.random() * 4) * 86400000);
  const reportDate = new Date(sampleDate.getTime() + Math.floor(1 + Math.random() * 3) * 86400000);
  return {
    fullName,
    leadType: isIndividual ? "Individual Patient" : "Corporate Client",
    patientName: fullName,
    patientAge: Math.floor(22 + Math.random() * 48),
    patientGender: Math.random() > 0.5 ? "Male" : "Female",
    email: isIndividual
      ? `${fullName.toLowerCase().replace(/\s+/g, ".")}${Math.floor(10 + Math.random() * 90)}@gmail.com`
      : `${fullName.toLowerCase().replace(/\s+/g, ".")}@${companyName.toLowerCase().replace(/\s+/g, "")}.in`,
    phone,
    companyName,
    city,
    state: city === "Mumbai" || city === "Pune" ? "Maharashtra" : city === "Bengaluru" ? "Karnataka" : "Delhi NCR",
    industry: isIndividual ? "Individual Healthcare" : companyName === "Dygo Diagnostics" ? "Healthcare" : "Enterprise",
    leadSource,
    budget: pick(budgetValues),
    leadScore: Math.floor(45 + Math.random() * 55),
    assignedExecutive,
    status: "New",
    pipelineStage: "New",
    priority: Math.random() > 0.72 ? "High" : "Medium",
    testPackage: diagnostic.package,
    tests: diagnostic.tests,
    doctorName: pick(doctors),
    sampleType: diagnostic.sample,
    sampleCollectionDate: sampleDate.toISOString(),
    reportDeliveryDate: reportDate.toISOString(),
    reportStatus: pick(["Pending", "Sample Collected", "Processing"]),
    documents: documentTypes.slice(0, Math.floor(2 + Math.random() * 3)),
    paymentStatus: pick(["Pending", "Partial", "Paid"]),
    followUpDate: new Date(Date.now() + 2 * 86400000).toISOString().slice(0, 10),
    notes: `Automatically generated Indian diagnostics lead for ${diagnostic.package}`
  };
}

async function generateLeadAndRefresh() {
  try {
    await api("/api/leads", { method: "POST", body: JSON.stringify(createAutoLead()) });
    if (!$("#app").classList.contains("hidden")) await loadAll();
    pushNotif("New lead assigned");
  } catch (error) {
    console.error(error);
  }
}

function startAutoGeneration() {
  if (state.autoTimer) return;
  state.autoTimer = setInterval(generateLeadAndRefresh, 15000);
  generateLeadAndRefresh();
}

function populateSelects() {
  $("#leadForm select[name='leadSource']").innerHTML = leadSources.map((item) => `<option>${item}</option>`).join("");
  $("#leadForm select[name='status']").innerHTML = statuses.map((item) => `<option>${item}</option>`).join("");
}

function bindEvents() {
  populateSelects();
  $$("#nav button").forEach((button) => button.addEventListener("click", () => showPage(button.dataset.page)));

  $("#loginForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const button = event.currentTarget.querySelector("button[type='submit']");
    button.disabled = true;
    button.textContent = "Logging in...";
    try {
      const data = formObject(event.currentTarget);
      const response = await api("/api/auth/login", { method: "POST", body: JSON.stringify({ email: data.email, password: data.password }) });
      state.token = response.token;
      state.user = response.user;
      localStorage.setItem("verifyProToken", response.token);
      localStorage.setItem("verifyProUser", JSON.stringify(response.user));
      showApp();
      await loadAll().catch((error) => toast(`Logged in. Sync issue: ${error.message}`));
      toast("Login successful");
    } catch (error) {
      localStorage.removeItem("verifyProToken");
      localStorage.removeItem("verifyProUser");
      state.token = "";
      state.user = null;
      showLogin();
      toast(error.message || "Login failed");
    } finally {
      button.disabled = false;
      button.textContent = "Login";
    }
  });

  $("#forgotBtn").addEventListener("click", async () => {
    const email = $("#loginForm input[name='email']").value;
    await api("/api/auth/forgot-password", { method: "POST", body: JSON.stringify({ email }) });
    toast("Password help notification created");
  });

  $("#logoutBtn").addEventListener("click", async () => {
    await api("/api/auth/logout", { method: "POST", body: JSON.stringify({ token: state.token }) }).catch(() => {});
    localStorage.removeItem("verifyProToken");
    localStorage.removeItem("verifyProUser");
    state.token = "";
    state.user = null;
    showLogin();
  });

  $("#refreshBtn").addEventListener("click", () => loadAll().then(() => toast("Refreshed")).catch((error) => toast(error.message)));
  $("#globalSearch").addEventListener("input", () => loadAll().catch((error) => toast(error.message)));
  $("#statusFilter").addEventListener("change", () => loadAll().catch((error) => toast(error.message)));
  $("#generateNowBtn").addEventListener("click", generateLeadAndRefresh);
  $("#exportCsvBtn").addEventListener("click", () => { window.location.href = "/api/exports/leads.csv"; });

  $("#metricGrid").addEventListener("click", (event) => {
    const card = event.target.closest("[data-dashboard-view]");
    if (card) openDashboardDetail(card.dataset.dashboardView);
  });

  $("#sourceBars").addEventListener("click", (event) => {
    const source = event.target.closest("[data-dashboard-source]");
    if (source) openDashboardDetail("source", source.dataset.dashboardSource);
  });

  $("#detailSearch").addEventListener("input", renderDashboardDetail);
  $("#detailFilter").addEventListener("change", renderDashboardDetail);
  $("#detailExportBtn").addEventListener("click", exportDetailReport);
  $("#detailCloseBtn").addEventListener("click", () => {
    state.detailView = "";
    state.detailSource = "";
    localStorage.removeItem("verifyProDetailView");
    localStorage.removeItem("verifyProDetailSource");
    $("#dashboardDetails").classList.add("hidden");
  });
  $("#detailRows").addEventListener("click", (event) => {
    const id = event.target.dataset.detailViewLead;
    if (id) showLeadDetails(state.leads.find((lead) => lead._id === id));
  });

  $("#leadForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const data = formObject(event.currentTarget);
    const id = data.id;
    delete data.id;
    await api(id ? `/api/leads/${id}` : "/api/leads", { method: id ? "PUT" : "POST", body: JSON.stringify(data) });
    clearLeadForm();
    await loadAll();
    toast("Lead saved");
  });

  $("#clearLeadBtn").addEventListener("click", clearLeadForm);

  $("#leadRows").addEventListener("click", async (event) => {
    const viewId = event.target.dataset.view;
    const editId = event.target.dataset.edit;
    const deleteId = event.target.dataset.delete;
    if (viewId) showLeadDetails(state.leads.find((lead) => lead._id === viewId));
    if (editId) fillLeadForm(state.leads.find((lead) => lead._id === editId));
    if (deleteId) {
      await api(`/api/leads/${deleteId}`, { method: "DELETE" });
      await loadAll();
      toast("Lead deleted");
    }
  });

  $("#closeDetailsBtn").addEventListener("click", () => $("#leadDetails").close());

  $("#pipelineBoard").addEventListener("dragstart", (event) => {
    const id = event.target.dataset.dragLead;
    if (id) event.dataTransfer.setData("text/plain", id);
  });

  $("#pipelineBoard").addEventListener("dragover", (event) => {
    if (event.target.closest("[data-drop-stage]")) event.preventDefault();
  });

  $("#pipelineBoard").addEventListener("drop", async (event) => {
    const column = event.target.closest("[data-drop-stage]");
    const id = event.dataTransfer.getData("text/plain");
    if (!column || !id) return;
    await api(`/api/leads/${id}/stage`, { method: "PATCH", body: JSON.stringify({ stage: column.dataset.dropStage }) });
    await loadAll();
    toast("Pipeline saved");
  });

  $("#followUpForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const data = formObject(event.currentTarget);
    const lead = state.leads.find((item) => item._id === data.leadId);
    await api("/api/followups", {
      method: "POST",
      body: JSON.stringify({ ...data, leadName: lead?.fullName || "Unknown Lead" })
    });
    event.currentTarget.reset();
    await loadAll();
    toast("Follow-up saved");
  });

  $("#followUpList").addEventListener("click", async (event) => {
    const id = event.target.dataset.followComplete;
    if (!id) return;
    await api(`/api/followups/${id}`, { method: "PATCH", body: JSON.stringify({ status: "Completed" }) });
    await loadAll();
    toast("Follow-up completed");
  });

  $("#teamForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const data = formObject(event.currentTarget);
    const id = data.id;
    delete data.id;
    await api(id ? `/api/team/${id}` : "/api/team", { method: id ? "PATCH" : "POST", body: JSON.stringify(data) });
    clearTeamForm();
    await loadAll();
    toast("Team member saved");
  });

  $("#clearTeamBtn").addEventListener("click", clearTeamForm);

  $("#teamList").addEventListener("click", async (event) => {
    const editId = event.target.dataset.teamEdit;
    const deleteId = event.target.dataset.teamDelete;
    if (editId) fillTeamForm(state.team.find((member) => member._id === editId));
    if (deleteId) {
      await api(`/api/team/${deleteId}`, { method: "DELETE" });
      await loadAll();
      toast("Team member deleted");
    }
  });

  $("#markReadBtn").addEventListener("click", async () => {
    await api("/api/notifications/read", { method: "PATCH" });
    await loadAll();
  });

  $("#clearNotificationsBtn").addEventListener("click", async () => {
    await api("/api/notifications", { method: "DELETE" });
    await loadAll();
  });
}

window.addEventListener("DOMContentLoaded", async () => {
  bindEvents();
  startAutoGeneration();
  if (state.token) {
    showApp();
    await loadAll().catch((error) => {
      localStorage.removeItem("verifyProToken");
      localStorage.removeItem("verifyProUser");
      state.token = "";
      state.user = null;
      showLogin();
      toast(error.message || "Please login again");
    });
  }
});
