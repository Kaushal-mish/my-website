$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$logDir = Join-Path $projectRoot "logs"
$nodeExe = "C:\Program Files\nodejs\node.exe"

if (-not (Test-Path -LiteralPath $logDir)) {
  New-Item -ItemType Directory -Path $logDir | Out-Null
}

Set-Location -LiteralPath $projectRoot
"[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Starting Verify Pro CRM from $projectRoot" | Add-Content -LiteralPath (Join-Path $logDir "server-start.log")
& $nodeExe "server.js" 1>> (Join-Path $logDir "server-start.log") 2>> (Join-Path $logDir "server-error.log")
