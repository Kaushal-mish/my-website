const Lead = require("./Lead");
const { Activity, ActivityLog, FollowUp, Notification, TeamMember } = require("./CrmModels");

const executives = ["Rahul Sharma", "Priya Verma", "Aman Gupta", "Neha Singh", "Arjun Mehta"];

function buildLeadPayload(body) {
  const assignedExecutive = String(body.assignedExecutive || "").trim() || executives[Math.floor(Math.random() * executives.length)];
  const status = body.status || "New";
  return {
    fullName: String(body.fullName || "").trim(),
    leadType: String(body.leadType || (body.companyName ? "Corporate Client" : "Individual Patient")).trim(),
    patientName: String(body.patientName || body.fullName || "").trim(),
    patientAge: body.patientAge === "" || body.patientAge === undefined ? undefined : Number(body.patientAge || 0),
    patientGender: String(body.patientGender || "").trim(),
    leadId: body.leadId ? String(body.leadId).trim() : undefined,
    email: String(body.email || "").trim(),
    phone: String(body.phone || body.mobileNumber || "").trim(),
    companyName: String(body.companyName || "").trim(),
    city: String(body.city || "").trim(),
    state: String(body.state || "").trim(),
    leadSource: String(body.leadSource || "Manual").trim(),
    industry: String(body.industry || "").trim(),
    leadScore: Number(body.leadScore || 0),
    budget: Number(body.budget || 0),
    assignedExecutive,
    status,
    pipelineStage: body.pipelineStage || body.stage || (status === "Converted" ? "Won" : status === "Lost" ? "Lost" : status),
    priority: body.priority || "Medium",
    testPackage: String(body.testPackage || "").trim(),
    tests: Array.isArray(body.tests) ? body.tests.map((item) => String(item).trim()).filter(Boolean) : String(body.tests || "").split(",").map((item) => item.trim()).filter(Boolean),
    doctorName: String(body.doctorName || "").trim(),
    sampleType: String(body.sampleType || "").trim(),
    sampleCollectionDate: body.sampleCollectionDate || undefined,
    reportDeliveryDate: body.reportDeliveryDate || undefined,
    reportStatus: String(body.reportStatus || "Pending").trim(),
    documents: Array.isArray(body.documents) ? body.documents.map((item) => String(item).trim()).filter(Boolean) : String(body.documents || "").split(",").map((item) => item.trim()).filter(Boolean),
    paymentStatus: String(body.paymentStatus || "Pending").trim(),
    followUpDate: body.followUpDate || undefined,
    notes: String(body.notes || "").trim()
  };
}

async function recordLeadWorkflow(lead, action) {
  await Promise.all([
    Activity.create({
      type: "System",
      title: action === "create" ? "New lead assigned" : "Lead updated",
      message: `${lead.fullName} assigned to ${lead.assignedExecutive || "an executive"}`,
      leadId: lead._id,
      actor: "System"
    }),
    ActivityLog.create({
      action: action === "create" ? "lead.create" : "lead.update",
      entity: "Lead",
      entityId: lead._id.toString(),
      actor: "System",
      details: { leadId: lead.leadId, status: lead.status, assignedExecutive: lead.assignedExecutive }
    }),
    Notification.create({
      title: action === "create" ? "New Lead Assigned" : "Lead Updated",
      message: `${lead.fullName} from ${lead.companyName || "Unknown Company"} assigned to ${lead.assignedExecutive || "an executive"}`,
      channel: "In-App",
      status: "Unread"
    }),
    TeamMember.updateOne(
      { name: lead.assignedExecutive || "Unassigned" },
      {
        $setOnInsert: {
          email: `${String(lead.assignedExecutive || "unassigned").toLowerCase().replace(/[^a-z0-9]+/g, ".")}@dygodiagnostics.com`,
          role: "Sales Executive"
        },
        $inc: { leadsAssigned: action === "create" ? 1 : 0 }
      },
      { upsert: Boolean(lead.assignedExecutive) }
    )
  ]);

  if (lead.followUpDate) {
    await FollowUp.updateOne(
      { leadId: lead._id, status: { $ne: "Completed" } },
      {
        $set: {
          leadId: lead._id,
          leadName: lead.fullName,
          assignedTo: lead.assignedExecutive || "Unassigned",
          dueAt: lead.followUpDate,
          type: "Call",
          status: new Date(lead.followUpDate) < new Date() ? "Missed" : "Upcoming",
          notes: "Auto-created from lead follow-up date"
        }
      },
      { upsert: true }
    );
  }
}

function handleControllerError(error, res) {
  const isValidationError = error.name === "ValidationError" || error.name === "CastError";
  res.status(isValidationError ? 400 : 500).json({
    success: false,
    message: error.message
  });
}

// Get All Leads
exports.getLeads = async (req, res) => {
  try {
    const query = {};
    const search = String(req.query.search || "").trim();
    if (search) {
      query.$text = { $search: search };
    }

    if (req.query.status) {
      query.status = req.query.status;
    }

    const leads = await Lead.find(query).sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: leads.length,
      data: leads
    });
  } catch (error) {
    handleControllerError(error, res);
  }
};

// Get Single Lead
exports.getLead = async (req, res) => {
  try {
    const lead = await Lead.findById(req.params.id);

    if (!lead) {
      return res.status(404).json({
        success: false,
        message: "Lead not found"
      });
    }

    res.status(200).json({
      success: true,
      data: lead
    });
  } catch (error) {
    handleControllerError(error, res);
  }
};

// Create Lead
exports.createLead = async (req, res) => {
  try {
    const lead = await Lead.create(buildLeadPayload(req.body));
    await recordLeadWorkflow(lead, "create");

    res.status(201).json({
      success: true,
      message: "Lead created successfully",
      data: lead
    });
  } catch (error) {
    handleControllerError(error, res);
  }
};

// Update Lead
exports.updateLead = async (req, res) => {
  try {
    const lead = await Lead.findByIdAndUpdate(req.params.id, buildLeadPayload(req.body), {
      new: true,
      runValidators: true
    });

    if (!lead) {
      return res.status(404).json({
        success: false,
        message: "Lead not found"
      });
    }
    await recordLeadWorkflow(lead, "update");

    res.status(200).json({
      success: true,
      message: "Lead updated successfully",
      data: lead
    });
  } catch (error) {
    handleControllerError(error, res);
  }
};

// Delete Lead
exports.deleteLead = async (req, res) => {
  try {
    const lead = await Lead.findByIdAndDelete(req.params.id);

    if (!lead) {
      return res.status(404).json({
        success: false,
        message: "Lead not found"
      });
    }

    res.status(200).json({
      success: true,
      message: "Lead deleted successfully"
    });
  } catch (error) {
    handleControllerError(error, res);
  }
};
